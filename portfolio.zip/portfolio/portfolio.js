import { View, Text, Image, StyleSheet, TouchableOpacity, Dimensions } from 'react-native'
import React, { useState } from 'react'
const { width, height } = Dimensions.get('window');
import { ScrollView } from 'react-native-gesture-handler'
import { favImage } from './Image_api/FavImage';
import { featuresImage } from './Image_api/featureImage';
import { commImage } from './Image_api/ComImage';
import { EditionImage } from './Image_api/EditionImage';

const Portfolio = () => {
  const [showFeat, setshowFeat] = useState(true);
  const [showFav, setShowFav] = useState(false);
  const [showComm, setshowComm] = useState(false);
  const [showEdit, setshowEdit] = useState(false);
  return (
    <View>
      <ScrollView>
        <Text style={{ alignSelf: "center", fontSize: 50 }}>Header</Text>
        <View style={{ alignItems: 'center', width: '90%', height: 100, flexDirection: 'row', justifyContent: 'space-between', marginHorizontal: 30 }}>
          <View>
            <Image
              style={{ height: 86, width: 86 }}
              source={require('../../assets/portfolio_pic.png')}
            />
          </View>
          <View style={{ width: 226, height: 60 }}>
            <Text style={{ textAlign: 'justify', marginEnd: 50, fontWeight: '500', fontSize: 14, }}>
              Hi, I’m a model with ABC Model Agency in San Francisco,
              CA who is interested in building a go...
            </Text>
          </View>
        </View>
        <View style={{ alignItems: 'center', width: '90%', height: 25, flexDirection: 'row', justifyContent: 'flex-start', marginHorizontal: 30 }}>
          <Image source={require("../../assets/rating.png")} />
          <Text style={{ marginStart: 10 }}> 4.9 </Text>
        </View>
        <View style={{ alignItems: 'center', width: '90%', height: 25, flexDirection: 'row', justifyContent: 'flex-start', marginHorizontal: 30 }}>
          <Image source={require("../../assets/loc.png")} />
          <Text style={{ marginStart: 10 }}> Los Angles USA </Text>
        </View>
        <View style={{ alignItems: 'center', width: '90%', height: 25, flexDirection: 'row', justifyContent: 'flex-start', marginHorizontal: 30 }}>
          <Image source={require("../../assets/type.png")} />
          <Text style={{ marginStart: 10 }}> Commercial, Glamour, Runway </Text>
          <Text style={styles.common_txt}> From 250</Text>
        </View>

        <TouchableOpacity style={styles.btnMainRow}>
          <Text style={{ textAlign: 'center', color: 'white' }}>Book Now </Text>
        </TouchableOpacity>
        <View style={[styles.common_flex, { marginTop: 10, width: '90%', }]}>
          <TouchableOpacity style={[styles.smal_btn, { width: '33%', }]}>
            <Text>Polaroid</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.smal_btn, { marginStart: 5, width: '33%' }]}>
            <Text>Message</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.smal_btn, { marginStart: 5, width: '15%' }]}>
            <Image style={{ width: 21, height: 21 }} source={require('../../assets/Instagram.png')} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.smal_btn, { marginStart: 5, width: '15%' }]}>
            <Image style={{ width: 21, height: 21 }} source={require('../../assets/group.png')} />
          </TouchableOpacity>

        </View>
        <View style={styles.TabBtnRow}>
          <TouchableOpacity style={[styles.Touch_btn, { borderBottomWidth: showFeat ? 1 : 0 }]} onPress={() => (setshowFeat(true), setShowFav(false), setshowComm(false), setshowEdit(false))}>
            <Text style={styles.custom_tab_btn}>Features</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.Touch_btn, { borderBottomWidth: showFav ? 1 : 0 }]} onPress={() => (setshowFeat(false), setShowFav(true), setshowComm(false), setshowEdit(false))}>
            <Text style={styles.custom_tab_btn}>Favourites</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.Touch_btn, { borderBottomWidth: showComm ? 1 : 0 }]} onPress={() => (setshowFeat(false), setShowFav(false), setshowComm(true), setshowEdit(false))}>
            <Text style={styles.custom_tab_btn}>Commercial</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.Touch_btn, { borderBottomWidth: showEdit ? 1 : 0 }]} onPress={() => (setshowFeat(false), setShowFav(false), setshowComm(false), setshowEdit(true))}>
            <Text style={styles.custom_tab_btn}>Editorial</Text>
          </TouchableOpacity>
        </View>

        <View style={{ display: showFeat ? 'flex' : 'none' }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 2 }}>
            {
              featuresImage.map((array) => {
                return (
                  <View style={{ margin: 2, width: 120, height: 200 }} key={array.id}>
                    <Image source={array.image_url} />
                  </View>
                )
              })
            }
          </View>
        </View>

        <View style={{ display: showFav ? 'flex' : 'none' }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 2 }}>
            {
              favImage.map((array) => {
                return (
                  <View style={{ margin: 2, width: 120, height: 200 }} key={array.id}>
                    <Image source={array.image_url} />
                  </View>
                )
              })
            }
          </View>
        </View>

        <View style={{ display: showComm ? 'flex' : 'none' }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 2 }}>
            {
              commImage.map((array) => {
                return (
                  <View style={{ margin: 2, width: 120, height: 200 }} key={array.id}>
                    <Image source={array.image_url} />
                  </View>
                )
              })
            }
          </View>
        </View>
        <View style={{ display: showEdit ? 'flex' : 'none' }}>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 2 }}>
            {
              EditionImage.map((array) => {
                console.log(array)
                return (
                  <View style={{ margin: 2, width: 120, height: 200 }} key={array.id}>
                    <Image source={array.image_url} />
                  </View>
                )
              })
            }
          </View>
        </View>
      </ScrollView>
    </View>
  )
}
const styles = StyleSheet.create({
  common_txt: {
    fontSize: 14,
    fontWeight: '500'
  },
  common_flex: {
    flexDirection: 'row',
    alignContent: 'center',
    alignSelf: 'center',
    justifyContent: 'center',
    width: '90%'
  },
  smal_btn: {

    height: 35,
    backgroundColor: '#EFEFEF',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center'
  },
  custom_tab_btn: {
    fontSize: 14,
    textAlign: 'center',
    fontWeight: '600',
    borderBottomWidth: 0
  },
  Touch_btn: {
    width: '25%',
    marginLeft: 10,
    paddingVertical: 20,

  },
  TabBtnRow: {
    alignItems: 'center',
    width: '90%',
    flexDirection: 'row',
    justifyContent: 'center',
    marginHorizontal: 30,
    borderBottomWidth: 1,
    borderBottomColor: '#d6d9d2'
    ,
    alignSelf: 'center'
  },
  btnMainRow: {
    width: '90%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    height: 35,
    marginTop: 20,
    backgroundColor: '#543B3A',
    borderRadius: 10
  }
})

export default Portfolio;