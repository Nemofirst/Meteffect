export  const favImage = [
    {
      id: 1,
      image_url: require('../assets/Bitmap-1.png'),
    },
    {
      id: 2,
      image_url: require('../assets/Bitmap.png'),
    },
    {
      id: 3,
      image_url: require('../assets/Bitmap.png'),
    },
    {
      id: 4,
      image_url: require('../assets/Bitmap-1.png'),
    }
  ]