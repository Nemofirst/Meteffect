export  const commImage = [
    {
        id: 1,
        image_url: require('../assets/Bitmap.png'),
      },
      {
        id: 2,
        image_url: require('../assets/Bitmap-1.png'),
      },
      {
        id: 3,
        image_url: require('../assets/Bitmap.png'),
      },
      {
        id: 4,
        image_url: require('../assets/Bitmap-1.png'),
      },
      {
        id: 5,
        image_url: require('../assets/Bitmap-1.png'),
      },
      {
        id: 6,
        image_url: require('../assets/Bitmap-1.png'),
      },

  ]